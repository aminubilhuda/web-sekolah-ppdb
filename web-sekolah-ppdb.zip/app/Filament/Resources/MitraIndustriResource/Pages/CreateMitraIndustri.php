<?php

namespace App\Filament\Resources\MitraIndustriResource\Pages;

use App\Filament\Resources\MitraIndustriResource;
use Filament\Resources\Pages\CreateRecord;

class CreateMitraIndustri extends CreateRecord
{
    protected static string $resource = MitraIndustriResource::class;
} 
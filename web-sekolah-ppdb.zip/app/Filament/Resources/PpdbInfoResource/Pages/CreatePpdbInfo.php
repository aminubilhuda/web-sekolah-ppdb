<?php

namespace App\Filament\Resources\PpdbInfoResource\Pages;

use App\Filament\Resources\PpdbInfoResource;
use Filament\Resources\Pages\CreateRecord;

class CreatePpdbInfo extends CreateRecord
{
    protected static string $resource = PpdbInfoResource::class;
} 
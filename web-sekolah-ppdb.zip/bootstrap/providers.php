<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\Filament\AbdiraPanelProvider::class,
    // App\Providers\TelescopeServiceProvider::class, // Disabled temporarily
];
